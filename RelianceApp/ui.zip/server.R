library(shiny)
library(dplyr)
library(tidyr)
library(ReliaEng)
library(progress)
library(survival)
library(plotly)
library(neuralnet)

#Constantes ------------------------------------------------------------
HIDDEN_SIZE<-c(3,3) #Neuronas en capa oculta
THRESHOLD<-1e-4 #Tolerancia absoluta de la NNet
LEARN_RATE<-.3 #Tasa de variacion de tasa de aprendizaje
REP_NNET<-5 #Repeticiones del entrenamiento de la NNet
FORMATO_FECHA<- "%Y-%m-%d %H:%M:%S" #Formato de fecha para importacion de datos
PDIST_X_DOTS<-500 #Puntos de la grafica de probabilidad

#Weibull_models con barra de progreso
Weibull_models_shiny<-function(time,status,id,shift.optimize=F,echo=T){
  t0.index<-which(time==0)
  time<-time[-t0.index]
  status<-status[-t0.index]
  id<-id[-t0.index]
  ids<-levels(id)
  modelos.ref<-list()
  modelos.coef<-data.frame(id=NULL,Shape=NULL,Scale=NULL,r2=NULL,n=NULL)
  withProgress(message = "Procesando modelos",detail = "esto tomara unos segundos...",{
    for(i in ids){
      incProgress(1/length(ids))
      index<-which(id==i)
      x<-Weibull_model(time[index],status[index],shift.optimize)
      c0<-Weibul_coef(x$est)
      r2<-summary(x$est)$r.squared
      
      modelos.ref[[length(modelos.ref)+1]]<-list(id=i,Model=x,Coef=c0)
      modelos.coef<-rbind(modelos.coef,data.frame(id=as.factor(i),Shape=c0[2],Scale=c0[1],R2=r2,n=x$n))
    }
  })
  return(list(ref=modelos.ref,coef=modelos.coef))
}


#Shiny Server
#---------------------------------------------------------------------------------------------------

shinyServer(function(input, output) {
  
  #Objetos del panel 1 --------------------------------------------------------------------
  
  #importar datos
  datax<-reactive({
    #datax<-read.csv2("e:/Reliance/test.csv")
    datax<-read.csv2(input$file$datapath)%>%select(-X)
    datax$Date<-as.POSIXct(strptime(datax$Date,format = FORMATO_FECHA))
    return(datax)
  })
  
  #Mostrar data
  output$data<-renderDataTable({
    datax()%>%select(Marca=Cat1,Ciudad=Cat2,Serie=Cat3,Evento=Event,Fecha=Date,Costo_Corr=C_Corr,Costo_Prev=C_Prev)
  })
  
  #Mostrar coef
  output$resData<-renderTable({
    datax()%>%group_by(Marca=Cat1,Ciudad=Cat2)%>%summarise(Nro_datos=n())
  })
  
  
  #Objetos del panel 2 --------------------------------------------------------------------
  
  #procesar datos en coef
  data.coef<-eventReactive(input$procesar,ignoreInit = T,{
    data.model<-Weibull_models_shiny(time=ttl(date=datax()$Date,
                                              id=datax()$Ref),
                                     status=datax()$Event,
                                     id=datax()$Ref,
                                     shift.optimize=T)
    return(left_join(data.model$coef,datax()%>%select(Ref,Cat1,Cat2,Cat3)%>%unique(),by=c("id"="Ref")))
  })
  
  
  #Datos seleccionados en pestana de modelos estadisticos
  seldataModel1<-reactive({return(data.coef()%>%filter((Cat1==input$selCat1)&(Cat2==input$selCat2)&(Cat3==input$selCat3)))})
  seldataModel2<-reactive({return(data.coef()%>%filter((Cat1==input$selCat4)&(Cat2==input$selCat5)&(Cat3==input$selCat6)))})
  
  #grafico del panel de dist prob
  output$distPlot<-renderPlotly({
    xydata<-data.frame(
      t=seq(0,qweibull(0.995,shape=seldataModel1()$Shape,scale=seldataModel1()$Scale)*2,
            qweibull(0.995,seldataModel1()$Shape,seldataModel1()$Scale)/PDIST_X_DOTS))%>%
      mutate(d_prob1=dweibull(t,seldataModel1()$Shape,seldataModel1()$Scale),
             P_prob1=pweibull(t,seldataModel1()$Shape,seldataModel1()$Scale),
             d_prob2=dweibull(t,seldataModel2()$Shape,seldataModel1()$Scale),
             P_prob2=pweibull(t,seldataModel2()$Shape,seldataModel1()$Scale)
             )
    
    dplot<-ggplot(xydata,aes(x=t,y=d_prob1))+
      geom_line(colour="red",size=1.2)+
      geom_line(aes(x=t,y=d_prob2),colour="green",size=1.2)+
      coord_cartesian(xlim = c(0,input$sliderX))
    Pplot<-ggplot(xydata,aes(x=t,y=P_prob1))+
      geom_line(colour="red",size=1.2)+
      geom_line(aes(x=t,y=P_prob2),colour="green",size=1.2)+
      coord_cartesian(xlim = c(0,input$sliderX))
    subplot(dplot,Pplot,nrows = 2)
  })
  
  #tabla de coeficientes del panel de dist prob
  output$R2.1<-renderTable({
    x<-data.frame(Parametro=c("Coeficiente R2","Factor de forma","Factor de escala","Nro datos"),
                  Valor=c(seldataModel1()$R2,seldataModel1()$Shape,seldataModel1()$Scale,seldataModel1()$n))
    x$Valor[1:3]<-format(x$Valor[1:3],digits = 10)
    return(x)
  })
  output$R2.2<-renderTable({
    x<-data.frame(Parametro=c("Coeficiente R2","Factor de forma","Factor de escala","Nro datos"),
                  Valor=c(seldataModel2()$R2,seldataModel2()$Shape,seldataModel2()$Scale,seldataModel2()$n))
    x$Valor[1:3]<-format(x$Valor[1:3],digits = 10)
    return(x)
  })
  
  output$sliderX<-renderUI({
    mid<-qweibull(0.995,shape=seldataModel1()$Shape,scale=seldataModel1()$Scale)
    sliderInput("sliderX","Zoom en Eje X",min=round(mid/10,0),max=round(mid*2,0),value=round(mid,0),ticks = F,sep = "")
  })
  
  #seleccion de graficas en dist prob
  output$selCat1<-renderUI({selectInput("selCat1","Categoria 1 - item 1",data.coef()%>%select(Cat1)%>%unique())})
  output$selCat2<-renderUI({selectInput("selCat2","Categoria 2 - item 1",data.coef()%>%select(Cat2)%>%unique())})
  output$selCat3<-renderUI({selectInput("selCat3","Categoria 3 - item 1",data.coef()%>%select(Cat3)%>%unique())})
  output$selCat4<-renderUI({selectInput("selCat4","Categoria 1 - item 2",data.coef()%>%select(Cat1)%>%unique())})
  output$selCat5<-renderUI({selectInput("selCat5","Categoria 2 - item 2",data.coef()%>%select(Cat2)%>%unique())})
  output$selCat6<-renderUI({selectInput("selCat6","Categoria 3 - item 2",data.coef()%>%select(Cat3)%>%unique())})
  
  #Objetos del panel 3 --------------------------------------------------------------------
  
   #mostrar tabla de coeficientes
  output$coefTable<-renderDataTable({
    coef<-data.coef()
    coef%>%group_by(Cat1,Cat2)%>%summarise(Shape=mean(Shape),Scale=mean(Scale),R2_min=min(R2),n=sum(n))
  })
  
  #grafico del panel de inferencia
  output$coefPlot<-renderPlotly({
    ggplot(data.coef(),aes(x=Shape,y=Scale))+geom_point(aes(color=Cat1,shape=Cat2))
  })
  
  #seleccion de patrones para inferencia
  output$selInference<-renderUI({
    catList<-expand.grid(Cat1=datax()$Cat1%>%levels(),Cat2=datax()$Cat2%>%levels())
    inferenceChoices<-dplyr::setdiff(catList,data.coef()%>%select(Cat1,Cat2)%>%unique())
    checkboxGroupInput("inferenceData","inferencia de datos",
                       choiceNames = paste(inferenceChoices$Cat1,inferenceChoices$Cat2),
                       choiceValues = paste(inferenceChoices$Cat1,inferenceChoices$Cat2,sep = "~"))
  })
  
  #inferencia de datos
  inference<-eventReactive(input$inferencia,{
    
    if(input$metodo=="nnet"|T){ #QUITAR CONDICION TRUE PARA HACER FUNCIONAR EL IF .....................................
      #Preprocesamiento de entradas y salidas de NNet
      coef.scales<-list(Shape=max(data.coef()$Shape),Scale=max(data.coef()$Scale)) #Factores de escalado
      coef.nnet<-dummyVar(data.coef()%>%select(Cat1,Cat2))%>%cbind(
        data.frame(Shape=data.coef()$Shape/coef.scales$Shape,Scale=data.coef()$Scale/coef.scales$Scale))
      test.coef<-input$inferenceData%>%strsplit("~") #AJUSTAR test.coef ..............................................
      print(test.coef)
      
      #entrenamiento de red neuronal
      model.nnet<-neuralnet(formula = paste0("`",names(coef.nnet()%>%select(-c(Shape,Scale))),"`")%>%
                              paste(collapse = "+")%>%
                              paste0("Shape+Scale~",.)%>%
                              as.formula(),
                            data=coef.nnet,
                            threshold = THRESHOLD,
                            rep = REP_NNET,
                            hidden = HIDDEN_SIZE,
                            learningrate = LEARN_RATE,
                            lifesign = T)
      
      #Procesamiento de datos de inferencia en la NNet
      in.nnet<-array(rep(0,18),c(2,9))%>%as.data.frame() #AJUSTAR test.coef ..............................................
      names(in.nnet)<-names(coef.nnet)
      in.nnet[,names(test.coef%>%select(Cat1,Cat2)%>%unique()%>%dummyVar())]<-test.coef%>%select(Cat1,Cat2)%>%unique()%>%dummyVar()
      out.nnet<-compute(model.nnet,in.nnet%>%select(-c(Shape,Scale)))%>%as.data.frame()%>%select(contains("net.result")) #prediccion
      names(out.nnet)<-c("Shape","Scale")
      out.nnet<-cbind(test.coef%>%select(Cat1,Cat2)%>%unique(),out.nnet)
      out.nnet$Shape<-out.nnet$Shape*coef.scales$Shape # desescalado de los datos
      out.nnet$Scale<-out.nnet$Scale*coef.scales$Scale
    }
    
  })
  
})
