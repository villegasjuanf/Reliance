library(shiny)
library(plotly)

shinyUI(navbarPage(
  title="Reliance",
  tabPanel("1. Datos",sidebarLayout(
    sidebarPanel(
      tableOutput("resData")
    ),
    mainPanel(
      fileInput("file","Archivo"),
      dataTableOutput("data")
    )
  )),
  tabPanel("2. Modelos",sidebarLayout(
    sidebarPanel(
      actionButton("procesar",label="Crear modelos"),
      h4("Item 1"),
      uiOutput("selCat1"),
      uiOutput("selCat2"),
      uiOutput("selCat3"),
      h4("Item 2"),
      uiOutput("selCat4"),
      uiOutput("selCat5"),
      uiOutput("selCat6")
    ),
    mainPanel(
      uiOutput("sliderX"),
      plotlyOutput("distPlot"),
      splitLayout(
        verticalLayout(
          h5("Item 1 (Rojo)"),
          tableOutput("R2.1"),
          fluid=F),
        verticalLayout(
          h5("Item 2 (Verde)"),
          tableOutput("R2.2"),
          fluid = F)
        )
    )
  )),
  tabPanel("3. Inferencia",sidebarLayout(
    sidebarPanel(
      uiOutput("selInference"),
      selectInput("metodo","Metodo",c("Modelo de Cox" = "cox","Red Neuronal" = "nnet"),selected = "Red Neuronal"),
      actionButton("inferencia","Realizar inferencia")
    ),
    mainPanel(
      plotlyOutput("coefPlot"),
      dataTableOutput("coefTable")
    )
  ))
))
